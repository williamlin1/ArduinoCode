
If you are using the latest Circuits@Home USB Host Shield (or any USB Host Shield that uses the USB Host 2.0 Library), the Android Open Accessory Developer's Kit (ADK) version will not work.

This is a direct replacement for the AndroidAccessory library that is included with the(ADK) for those using the USB Host 2.0 Library.

Rather than changing all of your sketches to support the newer USB Host 2.0 Library, just use this AndroidAccessory library rather than the one included with the ADK.

If you have any questions, feel free to post on my blog ... arduinocodedog.blogspot.com ... I'll try to answer your questions.

Also, use this code however you want, but I make no warranty, expressed or implied, about the suitability of its use, and I will not be held accountable for any damages incurred during its use.
